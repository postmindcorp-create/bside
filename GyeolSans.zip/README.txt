Gyeol Sans (결 Sans) — v1.0
=============================

Pretendard × Paperlogy 기반 B.Side 브랜드 커스텀 서체.
한글은 Pretendard, 영문/숫자는 페이퍼로지(Paperlogy)를 결합했습니다.

※ 정확한 정체성: 처음부터 새로 그린 오리지널 서체가 아니라, Pretendard와
Paperlogy를 결합하고 코너·비율을 프로그램으로 다듬은 "커스텀 파생 폰트"입니다.
공식 표현: "Pretendard × Paperlogy 기반 브랜드 커스텀 폰트"

디자인 원리
-----------
"부드럽게 이어지는 곡선으로, 글자의 결을 만들다."

두 종류의 라운딩을 구분해서 적용합니다:
1. 끝단 캡(terminal cap) — 획이 허공에서 끝나는 자리는 반경을
   획 굵기의 절반까지 키워 확실히 둥글립니다 (36px 이상에서 육안 확인 가능).
2. 조인트(joint) — 두 획이 실제로 만나 꺾이는 지점은 굵기에 비례한
   작은 반경(20~46유닛)으로 미세하게만 다듬습니다.

여기에 더해 비율을 조정했습니다:
- 한글: 세로 +10%, 가로 −6% (글자 칸과 자간은 그대로 두고 중심 기준으로
  좁혀서, 더 크고 임팩트 있는 헤드라인 인상을 줍니다)
- 영문·숫자·기호: 가로 +10% (자폭이 함께 넓어져, Thin/Light 굵기와
  조합하면 가늘고 넓게 트래킹된 클래식 북커버 캡션 느낌을 냅니다)

구성 (9 weights)
-----------------
GyeolSans-Thin.ttf        (100)
GyeolSans-ExtraLight.ttf  (200)
GyeolSans-Light.ttf       (300)
GyeolSans-Regular.ttf     (400)
GyeolSans-Medium.ttf      (500)
GyeolSans-SemiBold.ttf    (600)
GyeolSans-Bold.ttf        (700)
GyeolSans-ExtraBold.ttf   (800)
GyeolSans-Black.ttf       (900)

베이스 구성 및 정확한 버전
---------------------------
한글       : Pretendard Version 1.309 (Kil Hyung-jin)
영문·숫자  : Paperlogy Version 1.001 (이주임 / PT&)

설치 방법
---------
Mac: 원하는 .ttf 파일을 더블클릭 → "글꼴 설치" 클릭
Windows: 원하는 .ttf 파일을 마우스 오른쪽 클릭 → "설치" 클릭
설치 후 "Gyeol Sans"로 검색하면 9개 굵기가 표시됩니다.

※ 이전에 다른 버전의 파일을 설치해보신 적이 있다면, 새 파일 설치 전에
기존 GyeolSans 폰트를 완전히 삭제하고 사용 중인 프로그램을 재시작해
주세요. 일부 프로그램(파워포인트 등)은 폰트 파일이 바뀌어도 예전 글자
모양을 캐시해서 계속 보여주는 경우가 있습니다.

라이선스 / 저작권
------------------
SIL Open Font License, Version 1.1. 전문은 동봉된 OFL.txt 참고.
(http://scripts.sil.org/OFL)

  Hangul base : Pretendard, Copyright (c) 2023 Kil Hyung-jin
                — Reserved Font Name 'Pretendard'
  Latin base  : Paperlogy, Copyright (c) 2024 PT& / Lee Juim
                — Reserved Font Name 'Paperlogy'
  수정 사항   : 끝단 캡 라운딩 + 조인트 라운딩 + 커닝 병합 + 소스 결합
                + 세로/가로 비율 조정 — B.Side, 2026

허용되는 것: 상업적·비상업적 사용, 복제, 배포, 수정, 재배포, 임베딩
금지되는 것: 폰트 소프트웨어 자체의 단독 판매, 원저작권자 이름을
            이용한 보증·후원 암시
필수 의무  : 배포되는 모든 사본에 저작권 고지와 OFL.txt를 함께 포함

상표 관련 (법률 자문 아님): OFL의 Reserved Font Name과 일반 상표법은
별개입니다. "Gyeol Sans" 명칭 및 B.Side 브랜드 표지 사용은 별도의
상표 정책에 따르며, 폰트 소프트웨어 자체는 OFL 1.1 조건을 따릅니다.

향후 저작 표기법
------------------
[간단히] Font: Gyeol Sans (Pretendard × Paperlogy 기반, by B.Side)
[각주] 본 문서는 Gyeol Sans(Pretendard × Paperlogy 기반 커스텀 서체)로
       제작되었습니다.
[정식] Gyeol Sans is based on Pretendard (c) Kil Hyung-jin and Paperlogy
       (c) PT&/Lee Juim, licensed under the SIL Open Font License 1.1.
[파일 전달 시 — 필수] README.txt와 OFL.txt를 반드시 함께 전달하세요.

알려진 한계
------------
- 한글(Pretendard)과 영문(Paperlogy)의 획 농도·마침표 크기·리듬은
  cap-height 정렬과 비율 조정 외에는 완전히 통일돼 있지 않습니다.
- "결" 자체의 조형(ㄱ/ㅕ/ㄹ의 관계 등)은 Pretendard 골격을 그대로
  쓰고 끝단·코너·비율만 다듬은 상태로, 완전히 독자적인 브랜드 글자
  조형은 아닙니다. (SF Pro Rounded가 SF Pro의 "라운디드 버전"이지
  애플의 독자 서체로 불리지 않는 것과 같은 포지션입니다.)
- 영문 획 두께 자체는 다시 그리지 않았습니다 — "가늘고 넓게"는
  가벼운 굵기(Thin/Light) 선택과 가로 확대를 조합해 낸 인상입니다.
- 이 항목들은 실제 타입 디자이너의 수작업 재설계가 필요한 영역입니다.
